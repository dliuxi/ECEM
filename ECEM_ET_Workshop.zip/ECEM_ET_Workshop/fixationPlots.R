######################################################################################################
# A code to plot fixation data overlaid on a screenshot of the screen
# Written by Alasdair Clarke
# Amendments by Dawn Liu
# University of Essex 2019
######################################################################################################

# call required packages from library (if you do not already have these installed, run install.packages("tidyverse") etc.)
library(tidyverse)
library(jpeg)
library(grid)

#----------------------------------------------------------------------------------------------------#
# We are running this demonstration using the WeatherFixations dataset.
# Data from an experiment on weather forecast viewing by Dawn Liu, Marie Juanchich, & Alasdair Clarke
#----------------------------------------------------------------------------------------------------#

# load your fixation dataset
directory <- paste0(getwd(),"/WeatherFixations")
setwd(directory)
fixation_data <- read_csv("fixation_data.csv")

# load your background image (e.g., a screenshot of the actual experiment screen)
stimuli <- readJPEG("StimuliImage.jpg")   # Test this with StimuliImage_2.jpg for a different image, or load your own in and try it out! (*Note, for the purposes of this example, the image dimension should be 1920 x 1080 because that was the experiment screen size.)
image <- rasterGrob(stimuli, interpolate = TRUE)  # This converts it to an image type that can work with the fixation plot.

# Here is the plot code: 
ggplot(fixation_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +            # note, we use 1080-Fixation_Y to flip the y-axis so that the plot goes from bottom up
  annotation_custom(image, xmin=1, xmax = 1920, ymin=1, ymax = 1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) + 
  geom_point(alpha = 0.05, colour = "lightskyblue2") +
  theme_void() + theme(legend.position = "none")

# save the produced image:
ggsave("fixation_plot.jpg")   # or give it your own special file name

#--------------------------------------MORE EXERCISES----------------------------------------------#

# Try this out with data from only one participant (the file 'single_participant.csv'), and with a different image!

single_data <- read_csv("single_participant.csv")

stimuli2 <- readJPEG("StimuliImage_2.jpg")
image2 <- rasterGrob(stimuli2, interpolate = TRUE)

# Here is the plot code again (with some adjustments so the dots show up more clearly): 
ggplot(single_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +            # note, we use 1080-Fixation_Y to flip the y-axis so that the plot goes from bottom up
  annotation_custom(image2, xmin=1, xmax = 1920, ymin=1, ymax = 1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) + 
  geom_point(alpha = 1, colour = "lightblue") +
  theme_void() + theme(legend.position = "none")

# save the produced image:
ggsave("fixation_plot_2.jpg")

#----------------------------------------------------------------------------------------------------#

# Try this out with a different dataset with different dimensions! (from the folder FoodFixations, from a study on food labels--doi: 10.17605/OSF.IO/54TPD)

setwd('..')
directory <- paste0(getwd(),"/FoodFixations")
setwd(directory)
fixation_data <- read_csv("fixation_data.csv")

stimuli <- readJPEG("StimuliImage.jpg")  # the image dimensions are 1024 x 768
image <- rasterGrob(stimuli, interpolate = TRUE)

ggplot(fixation_data, aes(x = Fixation_X, y = 768-Fixation_Y)) +            # note, we use 768-Fixation_Y to flip the y-axis so that the plot goes from bottom up
  annotation_custom(image, xmin=1, xmax = 1024, ymin=1, ymax = 768) +
  coord_fixed(1, xlim = c(1, 1024), ylim = c(1, 768), expand = FALSE) + 
  geom_point(alpha = 0.05, colour = "lightskyblue2") +
  theme_void() + theme(legend.position = "none")
  
ggsave("food_label_fixations.jpg")

# or with one participant only, and different image:

single_data <- read_csv("single_participant.csv")

stimuli2 <- readJPEG("StimuliImage_2.jpg")
image2 <- rasterGrob(stimuli2, interpolate = TRUE)

ggplot(single_data, aes(x = Fixation_X, y = 768-Fixation_Y)) +            
  annotation_custom(image2, xmin=1, xmax = 1024, ymin=1, ymax = 768) +
  coord_fixed(1, xlim = c(1, 1024), ylim = c(1, 768), expand = FALSE) + 
  geom_point(alpha = 1, colour = "lightblue") +
  theme_void() + theme(legend.position = "none")

ggsave("food_label_fixations_2.jpg")

#----------------------------------------------------------------------------------------------------#

# More experienced users might like to play around with colours and sizes. Here is a version that can do that:

specified_colour <- "lightskyblue2"   # I used lightskyblue2 as the default colour, but you can use any of the ones found here: http://sape.inf.usi.ch/quick-reference/ggplot2/colour
transparency <- 0.05  # This makes the dots more or less see-through, on a scale of 0-1 where 1 is completely opaque and 0 is completely transparent. 

ggplot(fixation_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +            # note, we use 1080-Fixation_Y to flip the y-axis so that the plot goes from bottom up
  annotation_custom(image, xmin=1, xmax = 1920, ymin=1, ymax = 1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) + 
  geom_point(alpha = transparency, colour = specified_colour) +
  theme_void() + theme(legend.position = "none")

ggsave("customised_fixation_plot.jpg")

#----------------------------------------------------------------------------------------------------#

