######################################################################################################
# Codes for heat maps, scan paths, and fixation durations
# Written by Alasdair Clarke
# Amendments by Dawn Liu
# University of Essex 2019
######################################################################################################

# call required packages from library (if you do not already have these installed, run install.packages("tidyverse") etc.)
library(tidyverse)
library(jpeg)
library(grid)

#----------------------------------------------------------------------------------------------------#
# We are running this demonstration using the WeatherFixations dataset.
# Data from an experiment on weather forecast viewing by Dawn Liu, Marie Juanchich, & Alasdair Clarke
#----------------------------------------------------------------------------------------------------#

# load your fixation dataset
directory <- paste0(getwd(),"/WeatherFixations")
setwd(directory)
single_data <- read_csv("single_participant_2.csv")

# load your background image (e.g., a screenshot of the actual experiment screen)
stimuli <- readJPEG("StimuliImage.jpg")   # Test this with StimuliImage_2.jpg for a different image, or load your own in and try it out! (*Note, for the purposes of this example, the image dimension should be 1920 x 1080 because that was the experiment screen size.)
image <- rasterGrob(stimuli, interpolate = TRUE)  # This converts it to an image type that can work with the fixation plot.

# Let's do a scan path first for the participants' fixations, with lines connecting each one to show how their eyes travelled

ggplot(single_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +
  annotation_custom(image, xmin=1, xmax=1920, ymin=1, ymax=1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) +	
  geom_path(colour = "blue", alpha = 0.5) +
  geom_point(colour = "green", alpha = 0.5) +
  theme_void() + theme(legend.position="none")

ggsave("scanpath.png")

# We can also make the size of the fixation points correspond with how long the participant looked at that point. 

ggplot(single_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +
  annotation_custom(image, xmin=1, xmax=1920, ymin=1, ymax=1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) +	
  geom_path(colour = "blue", alpha = 0.5) +
  geom_point(aes(size = Fixation_Duration), colour = "green", alpha = 0.5) +
  theme_void() + theme(legend.position="none")

ggsave("scanpath_with_duration.png")

# Here is an example to make a heat map across a lot of participants that uses colours to indicate places that received more fixations

fixation_data <- read_csv("fixation_data.csv")

stimuli2 <- readJPEG("StimuliImage_2.jpg")
image2 <- rasterGrob(stimuli, interpolate = TRUE)

# From this plot, you will see colour transitions, with light blues indicating places that received more fixations:
ggplot(fixation_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +
  annotation_custom(image2, xmin=1, xmax=1920, ymin=1, ymax=1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) +	
  geom_hex(bins = 200, alpha = 0.5) +   # bins sets how detailed the concentration will be, alpha how transparent
  theme_void() 

ggsave("heatmap.jpg") 

# We can make it pretty with pretty colours too!
library(viridis) # This is a package that makes pretty colours (but you can also use standard colour scales)

ggplot(fixation_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +
  annotation_custom(image2, xmin=1, xmax=1920, ymin=1, ymax=1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) +	
  geom_hex(bins = 200, alpha = 0.5) +   # bins sets how detailed the concentration will be, alpha how transparent
  scale_fill_viridis(direction=-1) + theme_void() 

ggsave("heatmap_pretty.jpg")

# What do you get if you have heat-maps AND fixation points? 

ggplot(fixation_data, aes(x = Fixation_X, y = 1080-Fixation_Y)) +
  annotation_custom(image, xmin=1, xmax=1920, ymin=1, ymax=1080) +
  coord_fixed(1, xlim = c(1, 1920), ylim = c(1, 1080), expand = FALSE) +	
  geom_hex(bins = 200, alpha = 0.3) +  
  geom_point(aes(color = Fixation_Duration), alpha = 0.02) +
  scale_color_viridis(discrete = F, direction = -1, option="magma") +
  scale_fill_viridis(direction=-1) + theme_void() 

ggsave("heatmap_with_duration.jpg")