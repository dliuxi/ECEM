######################################################################################################
# A code to clean an .asc file into the fixation data that we want to start analysing it
# Written by Dawn Liu
# University of Essex 2019
######################################################################################################

# install and load the eyelinker package from https://rdrr.io/cran/eyelinker/man/read.asc.html by Simon Barthelme
devtools::install_github
install.packages("eyelinker")
library(eyelinker)
library(dplyr)

# load your .asc file

eye_data <- read.asc("WQ_13.asc")

# sample visualisation: eye positions along the x-axis over time
plot(eye_data$raw$time,eye_data$raw$xp,xlab="Time (ms)",ylab="Eye position along x axis (pix)")

# we just want the fixations though
fixations <- eye_data$fix   # this is the list of fixations from the file

# We will now select just what we want and give them sensible names
library(tidyverse)
fixations <- fixations %>%
  rename(Fixation_Duration = dur,
         Fixation_X = axp,
         Fixation_Y = ayp,
         Trial_No = block
         ) %>%
  mutate(Trial_Time = etime - stime)

